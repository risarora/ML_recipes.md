# WELCOME TO SHERLOCK



### Density by Property Types Over Time

Using properties joined to lakes in the intersection table

1) **PropertiesByYear**: Residential, Industrial, Commercial, Agricultural, and Public properties by lake from 2003 - 2015 using the "Number of Properties per Lake" query

2) **PropertiesPctChangeByYear**: YoY change by property type by lake. Percentages in decimal format (Ex. 2.5 indicates a 250% increase)

3) **PropertiesPctOfTotalByYear**: Percentage of total by lake by year by type for 2003 - 2015.  -1 indicates a lack of the property type for that lake.
