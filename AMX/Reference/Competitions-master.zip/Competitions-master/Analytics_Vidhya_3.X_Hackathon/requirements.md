Requirements:
=============

 - Python
 - Pandas, Numpy, Scipy, Scikit-learn - latest libraries
 - XGBoost - https://github.com/dmlc/xgboost
 - Pypy (to run the ftrl code faster)
