# Analytics_Vidhya_3.X_Hackathon
Codes for the Analytics Vidhya Hackathon 3.X

Both the versions (weekend and weeklong) have shell scripts. Just run them and the solution is generated.

- The weekend codes have a public LB score: 0.8612 and private LB score: 0.8413. Runtimes ~6 min (4-core machine) - 2nd place
- The weekday codes have a public LB score: 0.8620 and private LB score: 0.8410. Runtimes ~ 32 min (4-core machine) - 1st place
