# Analytics-Vidhya-Hackathon-Customer-worth-to-a-bank-
# Analytics-Vidhya-Hackathon-Customer-worth-to-a-bank-
 The code corresponds to a single XGB model which gave me a public score of ~0.866 and a private score of ~0.84
 for the problem:
 http://discuss.analyticsvidhya.com/t/hackathon-3-x-predict-customer-worth-for-happy-customer-bank/3802
 
